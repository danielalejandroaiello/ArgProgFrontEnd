import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VeducacionComponent } from './veducacion.component';

describe('VeducacionComponent', () => {
  let component: VeducacionComponent;
  let fixture: ComponentFixture<VeducacionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VeducacionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VeducacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
