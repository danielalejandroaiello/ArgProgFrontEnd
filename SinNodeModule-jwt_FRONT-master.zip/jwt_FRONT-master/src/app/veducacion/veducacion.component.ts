import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Educacion } from '../models/educacion';
import { EducacionService } from '../service/educacion.service';

@Component({
  selector: 'app-veducacion',
  templateUrl: './veducacion.component.html',
  styleUrls: ['./veducacion.component.css']
})
export class VeducacionComponent implements OnInit {

  educaciones: Educacion[] = [];
  roles: string[];
  isAdmin = false;

  constructor(
    private educacionService: EducacionService,
    private toastr: ToastrService,
    
  ) { }

  ngOnInit() {
    
    this.cargarEducaciones();
   
  }

  cargarEducaciones(): void {
    this.educacionService.lista().subscribe(
      data => {
        this.educaciones = data;
      },
      err => {
        console.log(err);
      }
    );
  }


}
