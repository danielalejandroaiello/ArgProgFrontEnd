import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Experiencia } from '../models/experiencia';

@Injectable({
  providedIn: 'root'
})
export class ExperienciaService {

  //constructor() { }

  experienciaURL = 'http://localhost:8080/experiencia/';

  constructor(private httpClient: HttpClient) { }

  public lista(): Observable<Experiencia[]> {
    return this.httpClient.get<Experiencia[]>(this.experienciaURL + 'lista-experiencia');
  }

  public detail(id: number): Observable<Experiencia> {
    return this.httpClient.get<Experiencia>(this.experienciaURL + `detail-experiencia/${id}`);
  }

  public detailName(empresa: string): Observable<Experiencia> {
    return this.httpClient.get<Experiencia>(this.experienciaURL + `detailname-experiencia/${empresa}`);
  }

  public save(experiencia : Experiencia): Observable<any> {
    return this.httpClient.post<any>(this.experienciaURL + 'create-experiencia', experiencia);
  }

  public update(id: number, experiencia: Experiencia): Observable<any> {
    return this.httpClient.put<any>(this.experienciaURL + `update-experiencia/${id}`, experiencia);
  }

  public delete(id: number): Observable<any> {
    return this.httpClient.delete<any>(this.experienciaURL + `delete-experiencia/${id}`);
  }

}
