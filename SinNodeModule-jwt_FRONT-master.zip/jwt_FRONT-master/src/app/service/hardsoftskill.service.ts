import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Hardsoftskill } from '../models/hardsoftskill';

@Injectable({
  providedIn: 'root'
})
export class HardsoftskillService {

 // constructor() { }

 hardsoftskillURL = 'http://localhost:8080/hardsoftskill/';

  constructor(private httpClient: HttpClient) { }

  public lista(): Observable<Hardsoftskill[]> {
    return this.httpClient.get<Hardsoftskill[]>(this.hardsoftskillURL + 'lista-hardsoftskill');
  }

  public detail(id: number): Observable<Hardsoftskill> {
    return this.httpClient.get<Hardsoftskill>(this.hardsoftskillURL + `detail-hardsoftskill/${id}`);
  }

  public detailName(habilidad: string): Observable<Hardsoftskill> {
    return this.httpClient.get<Hardsoftskill>(this.hardsoftskillURL + `detailname-hardsoftskill/${habilidad}`);
  }

  public save(hardsoftskill : Hardsoftskill): Observable<any> {
    return this.httpClient.post<any>(this.hardsoftskillURL + 'create-hardsoftskill', hardsoftskill);
  }

  public update(id: number, hardsoftskill: Hardsoftskill): Observable<any> {
    return this.httpClient.put<any>(this.hardsoftskillURL + `update-hardsoftskill/${id}`, hardsoftskill);
  }

  public delete(id: number): Observable<any> {
    return this.httpClient.delete<any>(this.hardsoftskillURL + `delete-hardsoftskill/${id}`);
  }




}
