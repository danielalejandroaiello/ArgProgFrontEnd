export class Educacion {

    id?: number;
    titulo: string;
    instituto: string;
    fechaInicioFin: string;
    descripcion: string;
    

    constructor(titulo: string,instituto: string,fechaInicioFin: string,descripcion: string) {

        this.titulo = titulo;
        this.instituto = instituto;
        this.fechaInicioFin = fechaInicioFin;
        this.descripcion = descripcion;
       
    }

}

