import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VhardsoftskillComponent } from './vhardsoftskill.component';

describe('VhardsoftskillComponent', () => {
  let component: VhardsoftskillComponent;
  let fixture: ComponentFixture<VhardsoftskillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VhardsoftskillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VhardsoftskillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
