import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Hardsoftskill } from '../models/hardsoftskill';
import { HardsoftskillService } from '../service/hardsoftskill.service';

@Component({
  selector: 'app-vhardsoftskill',
  templateUrl: './vhardsoftskill.component.html',
  styleUrls: ['./vhardsoftskill.component.css']
})
export class VhardsoftskillComponent implements OnInit {

  hardsoftskills: Hardsoftskill[] = [];
  roles: string[];
  isAdmin = false;

  constructor(
    private hardsoftskillService: HardsoftskillService,
    private toastr: ToastrService,
    
  ) { }

  ngOnInit() {
    
    this.cargarHardSoftSkill();
   
  }

  cargarHardSoftSkill(): void {
    this.hardsoftskillService.lista().subscribe(
      data => {
        this.hardsoftskills = data;
      },
      err => {
        console.log(err);
      }
    );
  }


}
