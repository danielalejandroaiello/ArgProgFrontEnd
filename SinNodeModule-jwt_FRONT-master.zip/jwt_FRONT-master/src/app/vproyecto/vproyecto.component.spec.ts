import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VproyectoComponent } from './vproyecto.component';

describe('VproyectoComponent', () => {
  let component: VproyectoComponent;
  let fixture: ComponentFixture<VproyectoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VproyectoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VproyectoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
