import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Proyecto } from '../models/proyecto';
import { ProductoService } from '../service/producto.service';
import { ProyectoService } from '../service/proyecto.service';

@Component({
  selector: 'app-vproyecto',
  templateUrl: './vproyecto.component.html',
  styleUrls: ['./vproyecto.component.css']
})
export class VproyectoComponent implements OnInit {

  proyectos: Proyecto[] = [];
  roles: string[];
  isAdmin = false;

  constructor(
    private proyectoService: ProyectoService,
    private toastr: ToastrService,
    
  ) { }

  ngOnInit() {
    
    this.cargarProyectos();
   
  }

  cargarProyectos(): void {
    this.proyectoService.lista().subscribe(
      data => {
        this.proyectos = data;
      },
      err => {
        console.log(err);
      }
    );
  }


}
