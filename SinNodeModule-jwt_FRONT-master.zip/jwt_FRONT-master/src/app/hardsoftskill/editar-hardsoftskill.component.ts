import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Hardsoftskill } from '../models/hardsoftskill';
import { HardsoftskillService } from '../service/hardsoftskill.service';

@Component({
  selector: 'app-editar-hardsoftskill',
  templateUrl: './editar-hardsoftskill.component.html',
  styleUrls: ['./editar-hardsoftskill.component.css']
})
export class EditarHardsoftskillComponent implements OnInit {

  hardsoftskill: Hardsoftskill = null;

  constructor(
    private hardsoftskillService: HardsoftskillService,
    private activatedRoute: ActivatedRoute,
    private toastr: ToastrService,
    private router: Router
  ) { }

  ngOnInit() {
    const id = this.activatedRoute.snapshot.params.id;
    this.hardsoftskillService.detail(id).subscribe(
      data => {
        this.hardsoftskill = data;
      },
      err => {
        this.toastr.error(err.error.mensaje, 'Fail', {
          timeOut: 3000,  positionClass: 'toast-top-center',
        });
        this.router.navigate(['/']);
      }
    );
  }

  onUpdate(): void {
    const id = this.activatedRoute.snapshot.params.id;
    this.hardsoftskillService.update(id, this.hardsoftskill).subscribe(
      data => {
        this.toastr.success('Hardsoftskill Actualizado', 'OK', {
          timeOut: 3000, positionClass: 'toast-top-center'
        });
        this.router.navigate(['/lista-hardsoftskill']);
      },
      err => {
        this.toastr.error(err.error.mensaje, 'Fail', {
          timeOut: 3000,  positionClass: 'toast-top-center',
        });
        // this.router.navigate(['/']);
      }
    );
  }

}
