import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalleHardsoftskillComponent } from './detalle-hardsoftskill.component';

describe('DetalleHardsoftskillComponent', () => {
  let component: DetalleHardsoftskillComponent;
  let fixture: ComponentFixture<DetalleHardsoftskillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetalleHardsoftskillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalleHardsoftskillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
