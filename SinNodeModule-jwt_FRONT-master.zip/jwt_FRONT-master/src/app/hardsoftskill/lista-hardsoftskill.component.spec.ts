import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaHardsoftskillComponent } from './lista-hardsoftskill.component';

describe('ListaHardsoftskillComponent', () => {
  let component: ListaHardsoftskillComponent;
  let fixture: ComponentFixture<ListaHardsoftskillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaHardsoftskillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaHardsoftskillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
