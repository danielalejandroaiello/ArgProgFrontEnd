import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { HardsoftskillService } from '../service/hardsoftskill.service';
import { Hardsoftskill } from '../models/hardsoftskill';



@Component({
  selector: 'app-nuevo-hardsoftskill',
  templateUrl: './nuevo-hardsoftskill.component.html',
  styleUrls: ['./nuevo-hardsoftskill.component.css']
})

export class NuevoHardsoftskillComponent implements OnInit {

  habilidad = '';
  nivel = '';

  constructor(
    private hardsoftskillService: HardsoftskillService,
    private toastr: ToastrService,
    private router: Router
    ) { }

  ngOnInit() {
  }

  onCreate(): void {
    const hardsoftskill = new Hardsoftskill(this.habilidad, this.nivel);
    this.hardsoftskillService.save(hardsoftskill).subscribe(
      data => {
        this.toastr.success('Hardsoftskill Creado', 'OK', {
          timeOut: 3000, positionClass: 'toast-top-center'
        });
        this.router.navigate(['/lista-hardsoftskill']);
      },
      err => {
        this.toastr.error(err.error.mensaje, 'Fail', {
          timeOut: 3000,  positionClass: 'toast-top-center',
        });
        // this.router.navigate(['/']);
      }
    );
  }



}
