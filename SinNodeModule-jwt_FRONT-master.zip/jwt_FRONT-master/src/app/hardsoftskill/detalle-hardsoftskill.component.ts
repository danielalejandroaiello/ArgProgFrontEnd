import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Hardsoftskill } from '../models/hardsoftskill';
import { HardsoftskillService } from '../service/hardsoftskill.service';

@Component({
  selector: 'app-detalle-hardsoftskill',
  templateUrl: './detalle-hardsoftskill.component.html',
  styleUrls: ['./detalle-hardsoftskill.component.css']
})
export class DetalleHardsoftskillComponent implements OnInit {

  hardsoftskill: Hardsoftskill = null;

  constructor(
    private hardsoftskillService: HardsoftskillService,
    private activatedRoute: ActivatedRoute,
    private toastr: ToastrService,
    private router: Router
  ) { }

  ngOnInit() {
    const id = this.activatedRoute.snapshot.params.id;
    this.hardsoftskillService.detail(id).subscribe(
      data => {
        this.hardsoftskill = data;
      },
      err => {
        this.toastr.error(err.error.mensaje, 'Fail', {
          timeOut: 3000,  positionClass: 'toast-top-center',
        });
        this.volver();
      }
    );
  }

  volver(): void {
    this.router.navigate(['/lista-hardsoftskill']);
  }


}
