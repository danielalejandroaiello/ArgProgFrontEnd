import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NuevoHardsoftskillComponent } from './nuevo-hardsoftskill.component';

describe('NuevoHardsoftskillComponent', () => {
  let component: NuevoHardsoftskillComponent;
  let fixture: ComponentFixture<NuevoHardsoftskillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NuevoHardsoftskillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NuevoHardsoftskillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
