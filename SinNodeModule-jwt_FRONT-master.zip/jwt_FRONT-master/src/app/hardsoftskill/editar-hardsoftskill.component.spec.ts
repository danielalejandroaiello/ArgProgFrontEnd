import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditarHardsoftskillComponent } from './editar-hardsoftskill.component';

describe('EditarHardsoftskillComponent', () => {
  let component: EditarHardsoftskillComponent;
  let fixture: ComponentFixture<EditarHardsoftskillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditarHardsoftskillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditarHardsoftskillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
