import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Hardsoftskill } from '../models/hardsoftskill';
import { HardsoftskillService } from '../service/hardsoftskill.service';
import { TokenService } from '../service/token.service';

@Component({
  selector: 'app-lista-hardsoftskill',
  templateUrl: './lista-hardsoftskill.component.html',
  styleUrls: ['./lista-hardsoftskill.component.css']
})
export class ListaHardsoftskillComponent implements OnInit {

  hardsoftskills: Hardsoftskill[] = [];
  roles: string[];
  isAdmin = false;

  constructor(
    private hardsoftskillService: HardsoftskillService,
    private toastr: ToastrService,
    private tokenService: TokenService
  ) { }

  ngOnInit() {
    this.cargarHardSoftSkill();
    this.roles = this.tokenService.getAuthorities();
    this.roles.forEach(rol => {
      if (rol === 'ROLE_ADMIN') {
        this.isAdmin = true;
      }
    });
  }

  cargarHardSoftSkill(): void {
    this.hardsoftskillService.lista().subscribe(
      data => {
        this.hardsoftskills = data;
      },
      err => {
        console.log(err);
      }
    );
  }

  borrar(id: number) {
    this.hardsoftskillService.delete(id).subscribe(
      data => {
        this.toastr.success('HardSoftSkill Eliminado', 'OK', {
          timeOut: 3000, positionClass: 'toast-top-center'
        });
        this.cargarHardSoftSkill();
      },
      err => {
        this.toastr.error(err.error.mensaje, 'Fail', {
          timeOut: 3000, positionClass: 'toast-top-center',
        });
      }
    );
  }


  

}
