import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaEducacionComponent } from './lista-educacion.component';

describe('ListaEducacionComponent', () => {
  let component: ListaEducacionComponent;
  let fixture: ComponentFixture<ListaEducacionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaEducacionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaEducacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
