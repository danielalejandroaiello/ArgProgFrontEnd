import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Educacion } from '../models/educacion';
import { EducacionService } from '../service/educacion.service';

@Component({
  selector: 'app-nuevo-educacion',
  templateUrl: './nuevo-educacion.component.html',
  styleUrls: ['./nuevo-educacion.component.css']
})
export class NuevoEducacionComponent implements OnInit {

 /*  constructor() { }

  ngOnInit() {
  } */

  titulo = '';
  instituto = '';
  fechaInicioFin = '';
  descripcion = '';
  

  constructor(
    private educacionService: EducacionService,
    private toastr: ToastrService,
    private router: Router
    ) { }

  ngOnInit() {
  }

  onCreate(): void {
    const educacion = new Educacion(this.titulo, this.instituto, this.fechaInicioFin, this.descripcion);
    this.educacionService.save(educacion).subscribe(
      data => {
        this.toastr.success('Educacion Creada', 'OK', {
          timeOut: 3000, positionClass: 'toast-top-center'
        });
        this.router.navigate(['/lista-educacion']);
      },
      err => {
        this.toastr.error(err.error.mensaje, 'Fail', {
          timeOut: 3000,  positionClass: 'toast-top-center',
        });
        // this.router.navigate(['/']);
      }
    );
  }


}
