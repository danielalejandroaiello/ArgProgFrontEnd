import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NuevoEducacionComponent } from './nuevo-educacion.component';

describe('NuevoEducacionComponent', () => {
  let component: NuevoEducacionComponent;
  let fixture: ComponentFixture<NuevoEducacionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NuevoEducacionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NuevoEducacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
