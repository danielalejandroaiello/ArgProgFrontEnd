import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Educacion } from '../models/educacion';
import { EducacionService } from '../service/educacion.service';

@Component({
  selector: 'app-detalle-educacion',
  templateUrl: './detalle-educacion.component.html',
  styleUrls: ['./detalle-educacion.component.css']
})
export class DetalleEducacionComponent implements OnInit {

 /*  constructor() { }

  ngOnInit() {
  } */

  educacion: Educacion = null;

  constructor(
    private educacionService: EducacionService,
    private activatedRoute: ActivatedRoute,
    private toastr: ToastrService,
    private router: Router
  ) { }

  ngOnInit() {
    const id = this.activatedRoute.snapshot.params.id;
    this.educacionService.detail(id).subscribe(
      data => {
        this.educacion = data;
      },
      err => {
        this.toastr.error(err.error.mensaje, 'Fail', {
          timeOut: 3000,  positionClass: 'toast-top-center',
        });
        this.volver();
      }
    );
  }

  volver(): void {
    this.router.navigate(['/lista-educacion']);
  }

}
