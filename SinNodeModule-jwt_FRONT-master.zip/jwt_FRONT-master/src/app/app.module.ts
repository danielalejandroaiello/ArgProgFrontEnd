import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { interceptorProvider } from './interceptors/prod-interceptor.service';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

// external
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { LoginComponent } from './auth/login.component';
import { RegistroComponent } from './auth/registro.component';
import { MenuComponent } from './menu/menu.component';
import { IndexComponent } from './index/index.component';
import { AcercadeComponent } from './acercade/acercade.component';


//experiencia
import { ListaExperienciaComponent } from './experiencia/lista-experiencia.component';
import { NuevoExperienciaComponent } from './experiencia/nuevo-experiencia.component';
import { EditarExperienciaComponent } from './experiencia/editar-experiencia.component';
import { DetalleExperienciaComponent } from './experiencia/detalle-experiencia.component';

import { VexperienciaComponent } from './vexperiencia/vexperiencia.component';

//educacion
import { ListaEducacionComponent } from './educacion/lista-educacion.component';
import { NuevoEducacionComponent } from './educacion/nuevo-educacion.component';
import { EditarEducacionComponent } from './educacion/editar-educacion.component';
import { DetalleEducacionComponent } from './educacion/detalle-educacion.component';
import { ListaHardsoftskillComponent } from './hardsoftskill/lista-hardsoftskill.component';
import { NuevoHardsoftskillComponent } from './hardsoftskill/nuevo-hardsoftskill.component';
import { DetalleHardsoftskillComponent } from './hardsoftskill/detalle-hardsoftskill.component';
import { EditarHardsoftskillComponent } from './hardsoftskill/editar-hardsoftskill.component';
import { ListaProyectoComponent } from './proyecto/lista-proyecto.component';
import { NuevoProyectoComponent } from './proyecto/nuevo-proyecto.component';
import { DetalleProyectoComponent } from './proyecto/detalle-proyecto.component';
import { EditarProyectoComponent } from './proyecto/editar-proyecto.component';
import { VhardsoftskillComponent } from './vhardsoftskill/vhardsoftskill.component';
import { VproyectoComponent } from './vproyecto/vproyecto.component';
import { VeducacionComponent } from './veducacion/veducacion.component';



@NgModule({
  declarations: [
    AppComponent,

    LoginComponent,
    RegistroComponent,
    MenuComponent,
    IndexComponent,
    AcercadeComponent,
    

    //vistas de experiencia
    ListaExperienciaComponent,
    NuevoExperienciaComponent,
    EditarExperienciaComponent,
    DetalleExperienciaComponent,
    VexperienciaComponent,

    //vistas de educacion 
    ListaEducacionComponent,
    NuevoEducacionComponent,
    EditarEducacionComponent,
    DetalleEducacionComponent,

   //vistas de educacion 
   ListaHardsoftskillComponent,
   NuevoHardsoftskillComponent,
   DetalleHardsoftskillComponent,
   EditarHardsoftskillComponent,

   //vistas proyecto
   ListaProyectoComponent,
   NuevoProyectoComponent,
   DetalleProyectoComponent,
   EditarProyectoComponent,
   VhardsoftskillComponent,
   VproyectoComponent,
   VeducacionComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    HttpClientModule,
    FormsModule
  ],
  providers: [interceptorProvider],
  bootstrap: [AppComponent]
})
export class AppModule { }
