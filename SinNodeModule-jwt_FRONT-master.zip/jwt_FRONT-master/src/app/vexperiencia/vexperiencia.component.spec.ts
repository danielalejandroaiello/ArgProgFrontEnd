import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VexperienciaComponent } from './vexperiencia.component';

describe('VexperienciaComponent', () => {
  let component: VexperienciaComponent;
  let fixture: ComponentFixture<VexperienciaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VexperienciaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VexperienciaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
