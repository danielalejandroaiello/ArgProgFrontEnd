import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Experiencia } from '../models/experiencia';
import { ExperienciaService } from '../service/experiencia.service';

@Component({
  selector: 'app-vexperiencia',
  templateUrl: './vexperiencia.component.html',
  styleUrls: ['./vexperiencia.component.css']
})
export class VexperienciaComponent implements OnInit {

 /*  constructor() { }

  ngOnInit() {
  }
 */

  
  /*
  constructor() { }

  ngOnInit() {
  }

  */

  experiencias: Experiencia[] = [];
  roles: string[];
  isAdmin = false;

  constructor(
    private experienciaService: ExperienciaService,
    private toastr: ToastrService,
    
  ) { }

  ngOnInit() {
    
    this.cargarExperiencias();
   
  }

  cargarExperiencias(): void {
    this.experienciaService.lista().subscribe(
      data => {
        this.experiencias = data;
      },
      err => {
        console.log(err);
      }
    );
  }

}
