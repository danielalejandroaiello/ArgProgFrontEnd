import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { IndexComponent } from './index/index.component';
import { LoginComponent } from './auth/login.component';
import { RegistroComponent } from './auth/registro.component';
import { ProdGuardService as guard } from './guards/prod-guard.service';
import { ListaExperienciaComponent } from './experiencia/lista-experiencia.component';
import { NuevoExperienciaComponent } from './experiencia/nuevo-experiencia.component';
import { EditarExperienciaComponent } from './experiencia/editar-experiencia.component';
import { DetalleExperienciaComponent } from './experiencia/detalle-experiencia.component';
import { ListaEducacionComponent } from './educacion/lista-educacion.component';
import { NuevoEducacionComponent } from './educacion/nuevo-educacion.component';
import { EditarEducacionComponent } from './educacion/editar-educacion.component';
import { DetalleEducacionComponent } from './educacion/detalle-educacion.component';
import { ListaHardsoftskillComponent } from './hardsoftskill/lista-hardsoftskill.component';
import { NuevoHardsoftskillComponent } from './hardsoftskill/nuevo-hardsoftskill.component';
import { DetalleHardsoftskillComponent } from './hardsoftskill/detalle-hardsoftskill.component';
import { EditarHardsoftskillComponent } from './hardsoftskill/editar-hardsoftskill.component';
import { ListaProyectoComponent } from './proyecto/lista-proyecto.component';
import { NuevoProyectoComponent } from './proyecto/nuevo-proyecto.component';
import { DetalleProyectoComponent } from './proyecto/detalle-proyecto.component';
import { EditarProyectoComponent } from './proyecto/editar-proyecto.component';




const routes: Routes = [

  { path: '', component: IndexComponent },
  { path: 'login', component: LoginComponent },
  { path: 'registro', component: RegistroComponent },
  
 
  //creo los nuevos path para experiencia

  { path: 'lista-experiencia', component: ListaExperienciaComponent, canActivate: [guard], data: { expectedRol: ['admin', 'user'] } },
  { path: 'nuevo-experiencia', component: NuevoExperienciaComponent, canActivate: [guard], data: { expectedRol: ['admin'] } },
  { path: 'editar-experiencia/:id', component: EditarExperienciaComponent, canActivate: [guard], data: { expectedRol: ['admin'] } },
  { path: 'detalle-experiencia/:id', component: DetalleExperienciaComponent, canActivate: [guard], data: { expectedRol: ['admin'] } },

  //creo los nuevos path para educacion

  { path: 'lista-educacion', component: ListaEducacionComponent, canActivate: [guard], data: { expectedRol: ['admin', 'user'] } },
  { path: 'nuevo-educacion', component: NuevoEducacionComponent, canActivate: [guard], data: { expectedRol: ['admin'] } },
  { path: 'editar-educacion/:id', component: EditarEducacionComponent, canActivate: [guard], data: { expectedRol: ['admin'] } },
  { path: 'detalle-educacion/:id', component: DetalleEducacionComponent, canActivate: [guard], data: { expectedRol: ['admin'] } },
  
//creo los nuevos path para hardsoftskill
  
{ path: 'lista-hardsoftskill', component: ListaHardsoftskillComponent, canActivate: [guard], data: { expectedRol: ['admin', 'user'] } },
{ path: 'nuevo-hardsoftskill', component: NuevoHardsoftskillComponent, canActivate: [guard], data: { expectedRol: ['admin', 'user'] } },
{ path: 'detalle-hardsoftskill/:id', component: DetalleHardsoftskillComponent, canActivate: [guard], data: { expectedRol: ['admin', 'user'] } },
{ path: 'editar-hardsoftskill/:id', component: EditarHardsoftskillComponent, canActivate: [guard], data: { expectedRol: ['admin', 'user'] } },

//creo los nuevos path para proyecto
{ path: 'lista-proyecto', component: ListaProyectoComponent, canActivate: [guard], data: { expectedRol: ['admin', 'user'] } },
{ path: 'nuevo-proyecto', component: NuevoProyectoComponent, canActivate: [guard], data: { expectedRol: ['admin', 'user'] } },
{ path: 'detalle-proyecto/:id', component: DetalleProyectoComponent, canActivate: [guard], data: { expectedRol: ['admin', 'user'] } },
{ path: 'editar-proyecto/:id', component: EditarProyectoComponent, canActivate: [guard], data: { expectedRol: ['admin', 'user'] } },

{ path: '**', redirectTo: '', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
